﻿namespace Gestor_de_oficina
{
    partial class FormInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInicial));
            this.imageFormCliente = new System.Windows.Forms.PictureBox();
            this.imageFormOficina = new System.Windows.Forms.PictureBox();
            this.imageFormAlugar = new System.Windows.Forms.PictureBox();
            this.imageFormVenda = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.imageAdicionarCarroVenda = new System.Windows.Forms.PictureBox();
            this.imageAdicionarCarroAluguer = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormOficina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormAlugar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormVenda)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageAdicionarCarroVenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageAdicionarCarroAluguer)).BeginInit();
            this.SuspendLayout();
            // 
            // imageFormCliente
            // 
            this.imageFormCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageFormCliente.Image = ((System.Drawing.Image)(resources.GetObject("imageFormCliente.Image")));
            this.imageFormCliente.Location = new System.Drawing.Point(25, 86);
            this.imageFormCliente.Name = "imageFormCliente";
            this.imageFormCliente.Size = new System.Drawing.Size(177, 177);
            this.imageFormCliente.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageFormCliente.TabIndex = 1;
            this.imageFormCliente.TabStop = false;
            this.imageFormCliente.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageFormCliente_MouseDown);
            this.imageFormCliente.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageFormCliente_MouseUp);
            // 
            // imageFormOficina
            // 
            this.imageFormOficina.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageFormOficina.Image = ((System.Drawing.Image)(resources.GetObject("imageFormOficina.Image")));
            this.imageFormOficina.Location = new System.Drawing.Point(250, 86);
            this.imageFormOficina.Name = "imageFormOficina";
            this.imageFormOficina.Size = new System.Drawing.Size(177, 177);
            this.imageFormOficina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageFormOficina.TabIndex = 2;
            this.imageFormOficina.TabStop = false;
            this.imageFormOficina.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageFormOficina_MouseDown);
            this.imageFormOficina.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageFormOficina_MouseUp);
            // 
            // imageFormAlugar
            // 
            this.imageFormAlugar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageFormAlugar.Image = ((System.Drawing.Image)(resources.GetObject("imageFormAlugar.Image")));
            this.imageFormAlugar.Location = new System.Drawing.Point(472, 86);
            this.imageFormAlugar.Name = "imageFormAlugar";
            this.imageFormAlugar.Size = new System.Drawing.Size(177, 177);
            this.imageFormAlugar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageFormAlugar.TabIndex = 3;
            this.imageFormAlugar.TabStop = false;
            this.imageFormAlugar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageFormAlugar_MouseDown);
            this.imageFormAlugar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageFormAlugar_MouseUp);
            // 
            // imageFormVenda
            // 
            this.imageFormVenda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageFormVenda.Image = ((System.Drawing.Image)(resources.GetObject("imageFormVenda.Image")));
            this.imageFormVenda.Location = new System.Drawing.Point(697, 86);
            this.imageFormVenda.Name = "imageFormVenda";
            this.imageFormVenda.Size = new System.Drawing.Size(177, 177);
            this.imageFormVenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageFormVenda.TabIndex = 4;
            this.imageFormVenda.TabStop = false;
            this.imageFormVenda.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageFormVenda_MouseDown);
            this.imageFormVenda.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageFormVenda_MouseUp);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.imageAdicionarCarroVenda);
            this.groupBox1.Controls.Add(this.imageAdicionarCarroAluguer);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.imageFormVenda);
            this.groupBox1.Controls.Add(this.imageFormCliente);
            this.groupBox1.Controls.Add(this.imageFormAlugar);
            this.groupBox1.Controls.Add(this.imageFormOficina);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(891, 320);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Escolha uma opção";
            // 
            // imageAdicionarCarroVenda
            // 
            this.imageAdicionarCarroVenda.Image = ((System.Drawing.Image)(resources.GetObject("imageAdicionarCarroVenda.Image")));
            this.imageAdicionarCarroVenda.Location = new System.Drawing.Point(768, 269);
            this.imageAdicionarCarroVenda.Name = "imageAdicionarCarroVenda";
            this.imageAdicionarCarroVenda.Size = new System.Drawing.Size(45, 45);
            this.imageAdicionarCarroVenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imageAdicionarCarroVenda.TabIndex = 10;
            this.imageAdicionarCarroVenda.TabStop = false;
            this.imageAdicionarCarroVenda.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageAdicionarCarroVenda_MouseDown);
            this.imageAdicionarCarroVenda.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageAdicionarCarroVenda_MouseUp);
            // 
            // imageAdicionarCarroAluguer
            // 
            this.imageAdicionarCarroAluguer.Image = ((System.Drawing.Image)(resources.GetObject("imageAdicionarCarroAluguer.Image")));
            this.imageAdicionarCarroAluguer.Location = new System.Drawing.Point(535, 269);
            this.imageAdicionarCarroAluguer.Name = "imageAdicionarCarroAluguer";
            this.imageAdicionarCarroAluguer.Size = new System.Drawing.Size(45, 45);
            this.imageAdicionarCarroAluguer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imageAdicionarCarroAluguer.TabIndex = 9;
            this.imageAdicionarCarroAluguer.TabStop = false;
            this.imageAdicionarCarroAluguer.MouseDown += new System.Windows.Forms.MouseEventHandler(this.imageAdicionarCarroAluguer_MouseDown);
            this.imageAdicionarCarroAluguer.MouseUp += new System.Windows.Forms.MouseEventHandler(this.imageAdicionarCarroAluguer_MouseUp);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(694, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Gestão de Venda";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(469, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Gestão de Aluguer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(247, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Gestão de Oficina";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Gestão de Clientes";
            // 
            // FormInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(915, 344);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormInicial";
            this.Text = "Real Stand";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormInicial_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.imageFormCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormOficina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormAlugar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageFormVenda)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageAdicionarCarroVenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageAdicionarCarroAluguer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox imageFormCliente;
        private System.Windows.Forms.PictureBox imageFormOficina;
        private System.Windows.Forms.PictureBox imageFormAlugar;
        private System.Windows.Forms.PictureBox imageFormVenda;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox imageAdicionarCarroVenda;
        private System.Windows.Forms.PictureBox imageAdicionarCarroAluguer;
    }
}

