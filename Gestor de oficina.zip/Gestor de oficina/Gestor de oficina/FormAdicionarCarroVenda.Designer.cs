﻿namespace Gestor_de_oficina
{
    partial class FormAdicionarCarroVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelextra5 = new System.Windows.Forms.Label();
            this.comboBoxExtra5 = new System.Windows.Forms.ComboBox();
            this.labelextra4 = new System.Windows.Forms.Label();
            this.comboBoxExtra4 = new System.Windows.Forms.ComboBox();
            this.labelextra3 = new System.Windows.Forms.Label();
            this.comboBoxExtra3 = new System.Windows.Forms.ComboBox();
            this.labelextra2 = new System.Windows.Forms.Label();
            this.comboBoxExtra2 = new System.Windows.Forms.ComboBox();
            this.labelextra1 = new System.Windows.Forms.Label();
            this.comboBoxExtra1 = new System.Windows.Forms.ComboBox();
            this.comboBoxnumext = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxCombustivel = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxNumChassi = new System.Windows.Forms.MaskedTextBox();
            this.comboBoxModelo = new System.Windows.Forms.ComboBox();
            this.comboBoxMarca = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(40, 310);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(321, 128);
            this.buttonAdicionar.TabIndex = 17;
            this.buttonAdicionar.Text = "Adicionar Carro";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelextra5);
            this.groupBox2.Controls.Add(this.comboBoxExtra5);
            this.groupBox2.Controls.Add(this.labelextra4);
            this.groupBox2.Controls.Add(this.comboBoxExtra4);
            this.groupBox2.Controls.Add(this.labelextra3);
            this.groupBox2.Controls.Add(this.comboBoxExtra3);
            this.groupBox2.Controls.Add(this.labelextra2);
            this.groupBox2.Controls.Add(this.comboBoxExtra2);
            this.groupBox2.Controls.Add(this.labelextra1);
            this.groupBox2.Controls.Add(this.comboBoxExtra1);
            this.groupBox2.Controls.Add(this.comboBoxnumext);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(393, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(395, 426);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extras";
            // 
            // labelextra5
            // 
            this.labelextra5.AutoSize = true;
            this.labelextra5.Location = new System.Drawing.Point(40, 353);
            this.labelextra5.Name = "labelextra5";
            this.labelextra5.Size = new System.Drawing.Size(52, 17);
            this.labelextra5.TabIndex = 11;
            this.labelextra5.Text = "Extra 5";
            this.labelextra5.Visible = false;
            // 
            // comboBoxExtra5
            // 
            this.comboBoxExtra5.FormattingEnabled = true;
            this.comboBoxExtra5.Location = new System.Drawing.Point(40, 373);
            this.comboBoxExtra5.Name = "comboBoxExtra5";
            this.comboBoxExtra5.Size = new System.Drawing.Size(251, 24);
            this.comboBoxExtra5.TabIndex = 10;
            this.comboBoxExtra5.Visible = false;
            // 
            // labelextra4
            // 
            this.labelextra4.AutoSize = true;
            this.labelextra4.Location = new System.Drawing.Point(40, 285);
            this.labelextra4.Name = "labelextra4";
            this.labelextra4.Size = new System.Drawing.Size(52, 17);
            this.labelextra4.TabIndex = 9;
            this.labelextra4.Text = "Extra 4";
            this.labelextra4.Visible = false;
            // 
            // comboBoxExtra4
            // 
            this.comboBoxExtra4.FormattingEnabled = true;
            this.comboBoxExtra4.Location = new System.Drawing.Point(40, 305);
            this.comboBoxExtra4.Name = "comboBoxExtra4";
            this.comboBoxExtra4.Size = new System.Drawing.Size(251, 24);
            this.comboBoxExtra4.TabIndex = 8;
            this.comboBoxExtra4.Visible = false;
            // 
            // labelextra3
            // 
            this.labelextra3.AutoSize = true;
            this.labelextra3.Location = new System.Drawing.Point(40, 218);
            this.labelextra3.Name = "labelextra3";
            this.labelextra3.Size = new System.Drawing.Size(52, 17);
            this.labelextra3.TabIndex = 7;
            this.labelextra3.Text = "Extra 3";
            this.labelextra3.Visible = false;
            // 
            // comboBoxExtra3
            // 
            this.comboBoxExtra3.FormattingEnabled = true;
            this.comboBoxExtra3.Location = new System.Drawing.Point(40, 238);
            this.comboBoxExtra3.Name = "comboBoxExtra3";
            this.comboBoxExtra3.Size = new System.Drawing.Size(251, 24);
            this.comboBoxExtra3.TabIndex = 6;
            this.comboBoxExtra3.Visible = false;
            // 
            // labelextra2
            // 
            this.labelextra2.AutoSize = true;
            this.labelextra2.Location = new System.Drawing.Point(40, 145);
            this.labelextra2.Name = "labelextra2";
            this.labelextra2.Size = new System.Drawing.Size(52, 17);
            this.labelextra2.TabIndex = 5;
            this.labelextra2.Text = "Extra 2";
            this.labelextra2.Visible = false;
            // 
            // comboBoxExtra2
            // 
            this.comboBoxExtra2.FormattingEnabled = true;
            this.comboBoxExtra2.Location = new System.Drawing.Point(40, 168);
            this.comboBoxExtra2.Name = "comboBoxExtra2";
            this.comboBoxExtra2.Size = new System.Drawing.Size(251, 24);
            this.comboBoxExtra2.TabIndex = 4;
            this.comboBoxExtra2.Visible = false;
            // 
            // labelextra1
            // 
            this.labelextra1.AutoSize = true;
            this.labelextra1.Location = new System.Drawing.Point(40, 75);
            this.labelextra1.Name = "labelextra1";
            this.labelextra1.Size = new System.Drawing.Size(52, 17);
            this.labelextra1.TabIndex = 3;
            this.labelextra1.Text = "Extra 1";
            this.labelextra1.Visible = false;
            // 
            // comboBoxExtra1
            // 
            this.comboBoxExtra1.FormattingEnabled = true;
            this.comboBoxExtra1.Location = new System.Drawing.Point(40, 95);
            this.comboBoxExtra1.Name = "comboBoxExtra1";
            this.comboBoxExtra1.Size = new System.Drawing.Size(251, 24);
            this.comboBoxExtra1.TabIndex = 2;
            this.comboBoxExtra1.Visible = false;
            // 
            // comboBoxnumext
            // 
            this.comboBoxnumext.FormattingEnabled = true;
            this.comboBoxnumext.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBoxnumext.Location = new System.Drawing.Point(167, 27);
            this.comboBoxnumext.Name = "comboBoxnumext";
            this.comboBoxnumext.Size = new System.Drawing.Size(121, 24);
            this.comboBoxnumext.TabIndex = 1;
            this.comboBoxnumext.SelectedIndexChanged += new System.EventHandler(this.comboBoxnumext_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Quantidade de extras";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxCombustivel);
            this.groupBox1.Controls.Add(this.maskedTextBoxNumChassi);
            this.groupBox1.Controls.Add(this.comboBoxModelo);
            this.groupBox1.Controls.Add(this.comboBoxMarca);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(375, 292);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // comboBoxCombustivel
            // 
            this.comboBoxCombustivel.FormattingEnabled = true;
            this.comboBoxCombustivel.Location = new System.Drawing.Point(28, 231);
            this.comboBoxCombustivel.Name = "comboBoxCombustivel";
            this.comboBoxCombustivel.Size = new System.Drawing.Size(321, 24);
            this.comboBoxCombustivel.TabIndex = 14;
            // 
            // maskedTextBoxNumChassi
            // 
            this.maskedTextBoxNumChassi.Location = new System.Drawing.Point(28, 50);
            this.maskedTextBoxNumChassi.Mask = "000000000";
            this.maskedTextBoxNumChassi.Name = "maskedTextBoxNumChassi";
            this.maskedTextBoxNumChassi.Size = new System.Drawing.Size(321, 22);
            this.maskedTextBoxNumChassi.TabIndex = 13;
            // 
            // comboBoxModelo
            // 
            this.comboBoxModelo.FormattingEnabled = true;
            this.comboBoxModelo.Location = new System.Drawing.Point(28, 168);
            this.comboBoxModelo.Name = "comboBoxModelo";
            this.comboBoxModelo.Size = new System.Drawing.Size(321, 24);
            this.comboBoxModelo.TabIndex = 11;
            // 
            // comboBoxMarca
            // 
            this.comboBoxMarca.FormattingEnabled = true;
            this.comboBoxMarca.Items.AddRange(new object[] {
            "Abarth",
            "Alfa Romeo",
            "Aston Martin",
            "Audi",
            "Bentley",
            "BMW",
            "Caterham",
            "Chevrolet",
            "Chrysler",
            "Citroen",
            "Corvette",
            "Dacia",
            "Daewoo",
            "Daihatsu",
            "Dodge",
            "DS",
            "Ferrari",
            "Fiat",
            "Ford",
            "Galloper",
            "Honda",
            "Hummer",
            "Hyundai",
            "Jaguar",
            "Jeep",
            "Kia",
            "Lada",
            "Lamborghini",
            "Lancia",
            "Land Rover",
            "Lexux",
            "Lotus",
            "Maserati",
            "Maybach",
            "Mazda",
            "Mercedes-Benz",
            "MG",
            "MINI",
            "Mitsubishi",
            "Morgan",
            "Nissan",
            "Opel",
            "Peugeot",
            "Porsche",
            "Renault",
            "Rolls-Royce",
            "Rover",
            "Saab",
            "Seat",
            "Skoda",
            "Smart",
            "SsangYong",
            "Subaru",
            "Suzuki",
            "Tata",
            "Tesla",
            "Toyota",
            "Volkswagen",
            "Volvo"});
            this.comboBoxMarca.Location = new System.Drawing.Point(28, 108);
            this.comboBoxMarca.Name = "comboBoxMarca";
            this.comboBoxMarca.Size = new System.Drawing.Size(321, 24);
            this.comboBoxMarca.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Número do Chassi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Combustível";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Marca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Modelo";
            // 
            // FormAdicionarCarroVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(801, 449);
            this.Controls.Add(this.buttonAdicionar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormAdicionarCarroVenda";
            this.Text = "x";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAdicionar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labelextra5;
        private System.Windows.Forms.ComboBox comboBoxExtra5;
        private System.Windows.Forms.Label labelextra4;
        private System.Windows.Forms.ComboBox comboBoxExtra4;
        private System.Windows.Forms.Label labelextra3;
        private System.Windows.Forms.ComboBox comboBoxExtra3;
        private System.Windows.Forms.Label labelextra2;
        private System.Windows.Forms.ComboBox comboBoxExtra2;
        private System.Windows.Forms.Label labelextra1;
        private System.Windows.Forms.ComboBox comboBoxExtra1;
        private System.Windows.Forms.ComboBox comboBoxnumext;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxCombustivel;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxNumChassi;
        private System.Windows.Forms.ComboBox comboBoxModelo;
        private System.Windows.Forms.ComboBox comboBoxMarca;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}